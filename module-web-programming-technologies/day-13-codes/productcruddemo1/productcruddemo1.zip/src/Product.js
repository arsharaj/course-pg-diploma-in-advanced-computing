export class Product{
    constructor(pid,pname,qty,price){
        this.pid=pid;
        this.pname=pname;
        this.qty=qty;
        this.price=price;
    }
}